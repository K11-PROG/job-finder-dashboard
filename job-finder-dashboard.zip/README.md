# 🌍 French-Speaking Job Finder – Basan Groupe

This web app searches caregiver, hospital staff, and housekeeping jobs in French-speaking countries and sends daily email alerts.

## 🚀 Features
- Web-based interface (Streamlit)
- Daily email job alerts
- Supports France, Belgium, Switzerland, Quebec, and more

## 📦 How to Run Locally

```bash
pip install -r requirements.txt
streamlit run job_dashboard.py
```

## 🌐 Live on Streamlit Cloud
Coming soon...

## 🔒 Developed by Basan Groupe HR